var searchData=
[
  ['winfun_5fctype',['winfun_ctype',['../namespace_events.html#a53a3637c291b42d27804ac1e184a1cb7',1,'Events.winfun_ctype()'],['../namespace_grab___callback.html#a28ae24083e86c784ce38aabe788434bc',1,'Grab_Callback.winfun_ctype()']]]
];
